# stock-management-system-javaFX
A desktop application built with javaFX that manage stocks.
NOTE: This application is not yet completed. Validation of numbers, tray notification, jasper report and exporting files to excel hasnt been implemented yet
