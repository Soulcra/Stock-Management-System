/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tools;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Manasseh
 */



public class Validate {
    public Validate(){
        
    }
    private Connection con;
    private PreparedStatement pst;
    private ResultSet rs;
    private Statement st;
    
    
    
    
}
